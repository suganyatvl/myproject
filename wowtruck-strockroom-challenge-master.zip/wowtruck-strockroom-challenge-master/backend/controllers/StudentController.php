<?php

namespace backend\controllers;

use Yii;
use backend\models\Student;
use backend\models\Sudentsearch;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use yii\data\ActiveDataProvider;
use common\models\User;
use yii\filters\AccessControl;


/**
 * StudentController implements the CRUD actions for Student model.
 */
class StudentController extends Controller
{
    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
		  'access' => [
           'class' => AccessControl::className(),
           'rules' => [
               [
                   'allow' => true,
                   'roles' => ['@'],
                   'matchCallback' => function ($rule, $action) {
                       return User::isUserAdmin(Yii::$app->user->identity->username);
                   }
               ],
           ],
       ],
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Student models.
     * @return mixed
     */
    public function actionIndex()
    {
        $searchModel = new Sudentsearch();
        $dataProvider = $searchModel->search(Yii::$app->request->queryParams);

        return $this->render('index', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }
	
	
	public function actionStudentlist()
    {
        $searchModel = new Sudentsearch();
        $dataProvider = $searchModel->searchStudent(Yii::$app->request->queryParams);

        return $this->render('studentlist', [
            'searchModel' => $searchModel,
            'dataProvider' => $dataProvider,
        ]);
    }
	
	 /**
     * @return subject-wise mark
     */
    public function actionSubjectmark()
    {
        $model = new Student();
        $query = $model->find()->select(['*',"SUM(english) AS eng_tot,AVG(english) AS eng_avg,SUM(maths) AS mat_tot,AVG(maths) AS mat_avg,SUM(science) AS scn_tot,AVG(science) AS scn_avg"])->one();
		 

       return $this->render('mark', [
            'model' => $query,
        ]);
    }

    /**
     * Displays a single Student model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
		$query = Student::find()->select(['student_mark_list.*','user.username AS student_name'])->joinWith(['studentname'])->where(['student_mark_list.id'=>$id])->one();
        return $this->render('view', [
            'model' => $query,
        ]);
    }

    /**
     * Creates a new Student model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new Student();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
			$id=$model->id;
			 $get_mark=Student::findOne($id);
			 $total=$get_mark->english+$get_mark->maths+$get_mark->science;
			 $avg=round(($total/3),2);
			 $model->total=$total;
			 $model->average=$avg;
			 if($model->save())
			 {
            	return $this->redirect(['view', 'id' => $id]);
			 }
			 else
			 {
				 print_r($model->geterrors());
				 exit;
			 }
        } else {
            return $this->render('create', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing Student model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->validate()) 
		{	
			 $total=$model->english+$model->maths+$model->science;
			 $avg=round(($total/3),2);
			 $model->total=$total;
			 $model->average=$avg;
			 if($model->save())
			 {
            return $this->redirect(['view', 'id' => $model->id]);
			 }
			 else
			 {
				 print_r($model->geterrors());
			 }
        } else {
            return $this->render('update', [
                'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing Student model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    /**
     * Finds the Student model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Student the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = Student::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
