<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model backend\models\Student */

$this->title = 'Subject wise total and average';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="student-view">

    <h1><?= Html::encode($this->title) ?></h1>


    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'eng_tot',
            'eng_avg',
            'mat_tot',
            'mat_avg',
            'scn_tot',
            'scn_avg',
            
        ],
    ]) ?>

</div>
