<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use common\models\User;
use yii\helpers\ArrayHelper;


/* @var $this yii\web\View */
/* @var $model backend\models\Student */
/* @var $form yii\widgets\ActiveForm */

$student_list=ArrayHelper::map(User::find()->where(['role'=>10])->all(), 'id', 'username');
?>

<div class="student-form">
<div class="row">
    <div class="col-sm-8">
    <?php $form = ActiveForm::begin(); ?>

   
     <?=$form->field($model, 'student_name')
        ->dropDownList(
            $student_list,           
			['prompt'=>'Select student']    // options
        );?>

    <?= $form->field($model, 'english')->textInput() ?>

    <?= $form->field($model, 'maths')->textInput() ?>

    <?= $form->field($model, 'science')->textInput() ?>

 

 

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Create' : 'Update', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>
</div>
</div>
</div>
