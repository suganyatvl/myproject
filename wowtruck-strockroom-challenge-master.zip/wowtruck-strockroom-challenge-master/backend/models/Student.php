<?php

namespace backend\models;
use common\models\User;

use Yii;

/**
 * This is the model class for table "student".
 *
 * @property integer $id
 * @property string $student_name
 * @property double $english
 * @property double $maths
 * @property double $science
 * @property integer $total
 * @property double $average
 * @property string $created_at
 * @property string $update_at
 */
class Student extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'student_mark_list';
    }

    /**
     * @inheritdoc
     */
	 public $eng_avg;
	 public $mat_avg;
	 public $scn_avg;
	 
	 public $eng_tot;
	 public $mat_tot;
	 public $scn_tot;
    public function rules()
    {
        return [
            [['student_name', 'english', 'maths', 'science'], 'required'],
            [['english', 'maths', 'science', 'average'], 'number'],
			[['english', 'maths', 'science'], 'number'],
            [['total'], 'integer'],
			[['english', 'maths', 'science'], 'compare' , 'compareValue'=> 100, 'operator' => '<='],
            [['created_at', 'update_at', 'total', 'average'], 'safe'],
            [['student_name'], 'string', 'max' => 100],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'student_name' => 'Student Name',
            'english' => 'English',
            'maths' => 'Maths',
            'science' => 'Science',
            'total' => 'Total',
            'average' => 'Average',
            'created_at' => 'Created At',
            'update_at' => 'Update At',
			'eng_avg' => 'English Average',
            'mat_avg' => 'Maths Maths',
            'scn_avg' => 'Science Average',
            'mat_tot' => 'Maths Total',
            'eng_tot' => 'English Total',
            'scn_tot' => 'Science Total',
            
        ];
    }
	public function getStudentname()
    {
        // a customer has many comments
        return $this->hasMany(User::className(), ['id' => 'student_name']);
    }
}
