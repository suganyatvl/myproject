<?php

namespace backend\models;

use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use backend\models\Student;
use common\models\User;


/**
 * Sudentsearch represents the model behind the search form about `backend\models\Student`.
 */
class Sudentsearch extends Student
{
    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['id', 'total'], 'integer'],
            [['student_name', 'created_at', 'update_at','student_name'], 'safe'],
            [['english', 'maths', 'science', 'average'], 'number'],
        ];
    }

    /**
     * @inheritdoc
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
	 
	 public function searchStudent($params)
    {
		  $query = User::find()->where(['role'=>10]);
		   $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);
		  return $dataProvider;
	}
    public function search($params)
    {
        $query = Student::find()->select(['student_mark_list.*','user.username AS student_name'])->joinWith(['studentname']);
		 // $query = Student::find()->select(['*','(maths + english + science ) AS total']);

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'english' => $this->english,
            'maths' => $this->maths,
            'science' => $this->science,
            'total' => $this->total,
            'average' => $this->average,
            'created_at' => $this->created_at,
            'update_at' => $this->update_at,
        ]);

        $query->andFilterWhere(['like', 'student_name', $this->student_name]);

        return $dataProvider;
    }
}
