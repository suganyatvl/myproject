<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model backend\models\Student */


?>
<div class="student-view">

    <h1>Mark list</h1>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'student_name',
            'english',
            'maths',
            'science',
            'total',
            'average',
            'created_at',
            'update_at',
        ],
    ]) ?>

</div>
